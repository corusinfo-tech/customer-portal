from frappe.model.document import Document


class MaintenanceSchedule(Document):
    pass

